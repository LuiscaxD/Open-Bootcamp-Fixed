import moduloOperaciones as mOp

def main () :
    sum = mOp.suma (2, 2)
    print ("El resultado de la suma es igual a:", sum)

if __name__ == "__main__":
    main()

def main () :
    res = mOp.resta (2, 2)
    print ("El resultado de la resta es igual a:", res)

if __name__ == "__main__":
    main()

def main () :
    div = mOp.divi (2, 2)
    print ("El resultado de la división es igual a:", div)

if __name__ == "__main__":
    main()

def main () :
    mult = mOp.multi (2, 2)
    print ("El resultado de la multiplicación es igual a:", mult)

if __name__ == "__main__":
    main()


