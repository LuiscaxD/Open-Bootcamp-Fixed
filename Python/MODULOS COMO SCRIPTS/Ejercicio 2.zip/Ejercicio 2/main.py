import time


hr = time.strftime('%H') 
min = time.strftime('%M') 

if int(hr) >= 19:
	print ("Es hora de irse a casa") 
else:
	print ("Quedan {} horas y {} minutos para el final de la jornada laboral.".format(18- int(hr), 59-int(min)))