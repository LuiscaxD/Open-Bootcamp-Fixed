class Estudiante{
    #nombre;
    _asignaturas = ["JavaScript", " HTML", " CSS"];

    constructor(nombre){
        this.#nombre = nombre;
    }

    obtenDatos(obj){
        return obj = {
            nombre: this.#nombre,
            asignaturas: this._asignaturas
        }
    }
}

const persona = new Estudiante("Luisca");
console.log(persona.obtenDatos());


