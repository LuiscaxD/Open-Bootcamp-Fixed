// Factorial de 10 con bucle while
var total = 1;
var i = 1
while(i<10){
    i++
    total = total * i
}
console.log(total)