// Factorial de 10 con bucle for
var total = 1;
for(var i = 1; i <= 10; i++){
    total = total * i;
}
console.log(total);

