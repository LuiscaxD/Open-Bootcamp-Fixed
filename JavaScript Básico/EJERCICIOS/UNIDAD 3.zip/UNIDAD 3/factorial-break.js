// Factorial de 10 con brake
var total = 1;
var i = 1
while(true){
    i++
    total = total * i
    if(i>=10){
        break
    }
}
console.log(total)



