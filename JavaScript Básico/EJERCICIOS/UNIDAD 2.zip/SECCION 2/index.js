// Fecha de nacimiento
const fechaCumpleaños = new Date(2003, 3, 12);
const fechaNacimiento = [fechaCumpleaños.getDate(), fechaCumpleaños.getMonth() +1, fechaCumpleaños.getFullYear()];

// Libro fecha y url
const fechaBerserk = new Date(1997, 9, 7);
const fechaBerserk1 = [fechaBerserk.getDate(), fechaBerserk.getMonth() +1, fechaBerserk.getFullYear()];
const urlBerserk = new URL("https://drive.google.com/drive/folders/1AGTMmyd_x__g_xbWczsAK99hg2IM74rS?usp=sharing");

// Datos
const datos = {
    nombre: "Luis Monterrozo",
    edad: 19,
    isDesarrollador: true,
    nacimiento: fechaNacimiento,
    libro:{
        titulo: "Berserk",
        autor: "Kentaro Miura",
        fecha: fechaBerserk1,
        url: urlBerserk
    }

}

console.log(datos)
