let nombre_str = "Luis";
let apellido_str = "Monterrozo";
let estudiante_str = `${nombre_str} ${apellido_str}`;
console.log(estudiante_str);

let estudianteMayus = estudiante_str.toUpperCase();
console.log(estudianteMayus);

let estudianteMinus = estudiante_str.toLowerCase();
console.log(estudianteMinus);

let largoEstudiante = estudiante_str.length;
console.log(largoEstudiante);

let primeraNombre = nombre_str.charAt(0);
console.log(primeraNombre);

let ultimaApellido = apellido_str.charAt(9);
console.log(ultimaApellido);

console.log(estudiante_str.replace(/ /g, ""));

let isInNombre = estudiante_str.includes(nombre_str);
console.log(isInNombre);





