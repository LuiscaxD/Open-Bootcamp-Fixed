const logger = require("./logger")

const numero = "XD";

const miFuncion = val => {
    if(typeof val === "number"){
        return val;
    }
    throw new Error("Este es un mensaje personalizado XD");
};

try{
    // Código que fallará xd
    const funcion = miFuncion(numero);
}catch(e){
    logger.error(`${e}`);
}