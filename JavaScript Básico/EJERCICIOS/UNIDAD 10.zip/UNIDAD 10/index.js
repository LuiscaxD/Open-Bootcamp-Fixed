import chalk from 'chalk';

import * as moduloMatematicas from "./controller.js";

const sum = moduloMatematicas.suma(1, 2);
console.log(`El resultado de suma 1 es igual a: ${sum}`);

const sum2 = moduloMatematicas.suma(4,5);
console.log(`El resultado de suma 2 es igual a: ${sum2}`);

const multi = moduloMatematicas.multiplica(sum, sum2);
console.log(chalk.green(`El resultado de la multiplicacion es: ${multi}`));


