let altura_cm = 174;
console.log(altura_cm);

let altura_mt = 1.74;
console.log(altura_mt);

let peso_kg = 79.83;
console.log(peso_kg);

let altura_mt_red_arr = Math.ceil(altura_mt);
console.log(altura_mt_red_arr);

let altura_mt_red_aba = Math.floor(altura_mt);
console.log(altura_mt_red_aba);

let OpB = (Number.MAX_VALUE + 1) === Number.MAX_VALUE;

console.log(OpB);
