hola();
function hola(){
    return true;
}

////////////////////////////////////////////////////////////////////

const miPromesa = new Promise((resolve) => {
    if(true){
        resolve();
    }else{
        reject();
    }
});

const myCallback = () => console.log("Hola soy una promesa");
setTimeout(myCallback, 5000);

miPromesa
    .then(() => console.log("Se ha ejecutado de forma correcta"))
    .catch(() => console.log("ERROR"))
    .finally(() => myCallback)

////////////////////////////////////////////////////////////////////

function* generaId(){
    let id = 0;
    while (true) {
        id = id +1 *2;
        if (id % 2 !== 0){
            return id
        }
        yield id
    }
    }
const gen = generaId();

console.log(gen.next().value);
console.log(gen.next().value);
console.log(gen.next().value);
console.log(gen.next().value);
console.log(gen.next().value);
