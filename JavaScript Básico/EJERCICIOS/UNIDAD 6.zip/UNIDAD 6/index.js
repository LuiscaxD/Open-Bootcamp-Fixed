const listaCompra = ["Pan", "Huevos", "Cilantro", "Perejil", "Arroz"];
console.log(listaCompra);


listaCompra.push("Aceite de girasol");
console.log(listaCompra);


listaCompra.pop();
console.log(listaCompra);


const peliculasFavoritas = [
    {titulo: "Pacific Rim", director: "Guillermo del Toro", dia: 01, mes: 07, anyo: 2013
    },
    {titulo: "Avengers", director: "Hermanos Russo", dia: 27, mes: 04, anyo: 2012
    },
    {titulo: "Un sueño posible", director: "John Hancock", dia: 20, mes: 11, anyo: 2009}
];


const peliculasDespuesDosKDiez = peliculasFavoritas.filter(obj => {
    if (obj.anyo >= 2010 && obj.mes >= 01 && obj.dia > 01 || obj.anyo >= 2010 && obj.mes >= 01 && obj.dia >= 01){
        return true;
    }else{
        return false
    }
})
console.log(peliculasDespuesDosKDiez);


const newArray = peliculasFavoritas.map(function(obj){
    var rObj = {};
    rObj = obj.director
    return rObj;
})
console.log(newArray);


const newArray_2 = peliculasFavoritas.map(function(obj){
    var rObj = {};
    rObj = obj.titulo
    return rObj;
})
console.log(newArray_2);


const listaConcat = newArray.concat(newArray_2);
console.log(listaConcat);

const listaFactorPropagacion = [...newArray, ...newArray_2];
console.log(listaFactorPropagacion);