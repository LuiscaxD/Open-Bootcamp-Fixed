function fibonacci(num){
    let fiboNum = [];
    fiboNum[0] = 0;
    fiboNum[1] = 1;
    for(let i = 2; i <= num; i++){
        fiboNum[i] = fiboNum[i - 2] + fiboNum[i - 1];
    }
    return fiboNum;
}

let array = fibonacci(6);
console.log(array);